# Deep Diver
Du bist ein Taucher mit Harpune im Meer, jedoch stören sich einige Meeresbewohner an dir und greifen dich an. 
Du musst dich also gegen die Meeresbewohner verteidigen!

Die Gegner schwimmen in geraden Linien und prallen an den Wänden ab. 

(die aktuellste Version des Spiels ist auch als Azure Web App hochgeladen unter: https://witty-sand-0d2a16d03.5.azurestaticapps.net/)

## Spiel
### Bewegung
Du bewegst dich mit WASD.

### Schießen
Du zielst mit der Maus und schießt mit der linken Maustaste (Schuss-Abklingzeit liegt bei 1 Sekunde).

### Fähigkeiten
Du hast 2 Fähigkeiten. Unten links siehst du mithilfe des abklingenden Graufilters, ob du sie benutzen kannst.

#### Dash (Spacebar)
Ein Dash, der standardmäßig nach links führt; wenn du dich momentan am Bewegen bist, so führt er in deine Bewegungsrichtung (5 Sekunden Fähigkeits-Abklingzeit).

#### Schild (Rechtsclick)
Ein Schild, das dich für 0.75 Sekunden unsterblich macht, während dieser Zeit prallen auch Gegner an dir ab (8 Sekunden Fähigkeits-Abklingzeit).

### Pause-Menü (R-Taste)
Durch das Klicken der R-Taste während des Spielens kommst du ins Pause Menü (Fortsetzen durch erneutes Drücken von R). 

### Berechnung des Scores
Der Score wird dir rechts oben angezeigt und wird fortlaufend hochgezählt. Er stellt sich zusammen aus (5 \* *enemies killed* + 2 \* *time elapsed*) und wird als End-Score ebenfalls im Gameover-Screen angezeigt.

### Gegnertypen
Das Spiel beginnt, indem 5 zufällige Gegner erschaffen werden. Alle 5 Sekunden wird ein neuer zufälliger Gegner irgendwo auf der Map erschaffen. Diese Rate verringert sich alle 20 Sekunden um 0.5 Sekunden (Minimum: 2).

#### Standard-Gegner
Eine Krabbe, die geradlinig schwimmt und dich in 2.5-Sekunden Intervallen abschießt, wenn du in ihrer Reichweite bist.
Sie hat 1 Leben.

#### Sniper
Ein elektrischer Aal, der immer auf der Stelle bleibt und dich in 4-Sekunden Intervallen abschießt, hier jedoch Vorsicht: Er hat unbeschränkte Reichweite und schießt anders als Krabben nicht auf deine Position, sondern versucht deine zukünftige Position vorrauszusagen.
Er hat ebenfalls 1 Leben.

#### Rammbock
Ein Kugelfisch, der geradlinig schwimmt, und, sobald er in Reichweite kommt, sich aufbläst und auf dich zufliegt. Er bekommt keinen Schaden, wenn er dich berührt.
Er hat 2 Leben.

#### Angsthase
Ein Tintenfisch, der geradlinig schwimmt, jedoch nicht immer gleich schnell: so ist er langsamer, wenn er seine Tentakel anzieht, und ein wenig schneller, wenn er diese wieder ausstreckt. Wenn er in Reichweite kommt, schießt er Tinte, welche beim Treffen keinen Schaden verursacht, sondern den Bildschirm kurzzeitig mit Tinte bedeckt. 
Er hat 1 Leben.

### Powerups
Alle 10 Sekunden wird ein zufälliges Powerup irgendwo auf der Map erschaffen. Dieses bleibt 10 Sekunden, bevor es wieder verschwindet (falls es nicht davor aufgesammelt wird). Die Erschaffungszeit geht alle 30 sekunden um 0.5 Sekunden runter, bis sie bei 8 Sekunden angekommen ist. 

#### Life
Du kannst das herzförmige Life-Powerup aufheben, um ein Leben wiederherzustellen (das Maximum von 3 Leben kannst du damit allerdings nicht überschreiten).

#### Stern
Wenn du den Stern aufhebst, wirst du für 8 Sekunden unverwundbar und tötest die alle Gegner (inklusive des Rammbocks) mit nur einer Berührung. Für diese Kills bekommst du auch Punkte. Während dieses Zeitraums kannst du nicht schießen! 

#### Machine Gun: 
Wenn du das Machine Gun Powerup aufhebst, kannst du für die Zeit des Powerups nicht manuell schießen. Stattdessen schießt für die nächsten 5 Sekunden automatisch 5 Schüsse pro Sekunde in die Richtung deines Mauszeigers.