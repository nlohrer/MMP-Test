Welcome to ThemesPlugin,
in order to start you have to click on Themes > Select Themes in the top menu.
You can choose and create your own Themes there!
Remember, some themes only work with the dark unity theme, some with the light.
But you will get notified if that's the case.
Have Fun!